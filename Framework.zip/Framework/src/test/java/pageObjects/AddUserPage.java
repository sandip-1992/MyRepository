package pageObjects;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;

import utilities.ObjectRepository;

public class AddUserPage extends BasePage{

	private static String xpath_addUserPageText=ObjectRepository.getLocator("AddUserPageText", "XPATH");
	private WebElement addUserPageText;
	public boolean verifyAddUserPage(){
		try{
			addUserPageText=this.getElement("xpath", xpath_addUserPageText);
			if(addUserPageText.getText().equalsIgnoreCase("ADD USER"))
				return true;
			else
				return false;
		}catch(Exception e){
			e.printStackTrace();
			String defectDes=e.getStackTrace().toString();
			this.forceQuitDriver(e.getMessage());
			System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
			System.out.println(defectDes);
			System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
			return false;
		}
	}
}
