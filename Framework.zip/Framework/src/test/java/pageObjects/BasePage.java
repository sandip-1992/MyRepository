package pageObjects;



import java.util.List;


import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;

import utilities.Log;
import utilities.PropertyController;


public class BasePage {
	private static String currentScenario;
	private static String scenarioId;
	private static String browser=PropertyController.getPropertry("browser");
	public static WebDriver driver;
	public static WebDriver getDriver() {
		return driver;
	}

	public static void setCurrentScenario(String scenario){
		currentScenario=scenario;
	}

	public static String getScenarioId(){
		return scenarioId;
	}

	public static void setScenarioId(String scId){
		scenarioId=scId;
	}

	public static String getCurrentScenario(){
		return currentScenario;
	}


	public void initiateDriver(){
		try{
			Log.info("***********************************************************");
			Log.info("Initiating new execution for Scenario : "+getCurrentScenario());
			Log.info("***********************************************************");
			if(browser.equalsIgnoreCase("Google Chrome")){
				System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
				driver=new ChromeDriver();
				driver.manage().window().maximize();
				Log.info("Chrome Browser satrted");
			}
			if(browser.equalsIgnoreCase("Internet Explorer")){
				System.setProperty("webdriver.ie.driver", "drivers\\IEDriverServer.exe");
				driver=new InternetExplorerDriver();
				driver.manage().window().maximize();
				Log.info("Internet Explorer Browser satrted");
			}
			if(browser.equalsIgnoreCase("Mozilla Firefox")){
				driver=new FirefoxDriver();
				driver.manage().window().maximize();
				Log.info("Mozilla Firefox Browser satrted");
			}
		}catch(Exception e){
			Log.error("Error encountered while opening "+browser);
		}
	}
	
	

	public void getUrl(){
		try{
			driver.get(PropertyController.getPropertry("url"));
			Log.info("URL  "+PropertyController.getPropertry("url")+" loaded");
		}catch(Exception e){
			e.printStackTrace();
			Log.error("Error Loading URL "+PropertyController.getPropertry("url"));
		}
	}

	public void quitDriver(){
		if(driver!=null){
			driver.quit();
			Log.info(browser+" Instance stopped");
			Log.info("************************************************");
			Log.info("Execution ended for Scenario :"+getCurrentScenario()+" successfully");
			Log.info("************************************************");
		}
		else{
			Log.error("Error while stopping "+browser+". No Browser Found");
			Log.info("************************************************");
			Log.info("Execution ended for Scenario :"+getCurrentScenario()+" with error");
			Log.info("************************************************");
		}
	}

	public void forceQuitDriver(String errorMessage){
		Log.info("Error occured. Stopping "+browser+"instance");
		if(driver!=null){
			driver.quit();
			Log.info(browser+" Instance stopped");
			Log.info("************************************************");
			Log.info("Execution ended for Scenario :"+getCurrentScenario()+" with error");
			Log.info("************************************************");
		}
		else{
			Log.info("No "+browser+" Instance found");
			Log.info("************************************************");
			Log.info("Execution ended for Scenario :"+getCurrentScenario()+" with error");
			Log.info("************************************************");
		}
	}

	public WebElement getElement(String type,String value){
		List<WebElement> elements=null;
		try{
			if(type.equalsIgnoreCase("xpath")){
				int counter=0;
				while(counter<10){
					elements=driver.findElements(By.xpath(value));
					if(elements.size()>0)
						break;
					Thread.sleep(500);
					counter++;
				}
			}
			else if(type.equalsIgnoreCase("id")){
				int counter=0;
				while(counter<100){
					elements=driver.findElements(By.id(value));
					if(elements.size()>0)
						break;
					Thread.sleep(500);
					counter++;
				}
			}
			else if(type.equalsIgnoreCase("name")){
				int counter=0;
				while(counter<100){
					elements=driver.findElements(By.name(value));
					if(elements.size()>0)
						break;
					Thread.sleep(500);
					counter++;
				}
			}
			else if(type.equalsIgnoreCase("css")){
				int counter=0;
				while(counter<100){
					elements=driver.findElements(By.cssSelector(value));
					if(elements.size()>0)
						break;
					Thread.sleep(500);
					counter++;
				}
			}
			if(elements.size()>0)
				Log.info("WebElement found with "+type+" "+value);
			return elements.get(0);
		}catch(IndexOutOfBoundsException e){
			this.forceQuitDriver(e.getMessage());
			Log.error("Failed to load WebElement with "+type+" "+value);
		}catch(WebDriverException e){
			this.forceQuitDriver(e.getMessage());
			Log.error("WebDriver error while loading WebElement with "+type+" "+value);
		}
		catch(Exception e){
			this.forceQuitDriver(e.getMessage());
			Log.error("Error while loading WebElement with "+type+" "+value);
		}
		return null;
	}

	public boolean verifyElement(String type,String value){
		Log.info("Verifying WWebElement with "+type+" "+value);
		List<WebElement> elements=null;
		boolean isElementPresent=false;
		try{
			if(type.equalsIgnoreCase("xpath")){
				int counter=0;
				while(counter<10){
					elements=driver.findElements(By.xpath(value));
					if(elements.size()>0)
						isElementPresent=true;
					counter++;
				}
			}
			else if(type.equalsIgnoreCase("id")){
				int counter=0;
				while(counter<10){
					elements=driver.findElements(By.id(value));
					if(elements.size()>0)
						isElementPresent=true;
					counter++;
				}
			}
			else if(type.equalsIgnoreCase("name")){
				int counter=0;
				while(counter<10){
					elements=driver.findElements(By.name(value));
					if(elements.size()>0)
						isElementPresent=true;
					counter++;
				}
			}
			else if(type.equalsIgnoreCase("css")){
				int counter=0;
				while(counter<10){
					elements=driver.findElements(By.cssSelector(value));
					if(elements.size()>0)
						isElementPresent=true;
					counter++;
				}
			}
			if(isElementPresent)
				Log.info("WebElement found with "+type+" "+value);
			else
				Log.info("WebElement not found with "+type+" "+value);;
			return isElementPresent;
		}catch(WebDriverException e){
			this.forceQuitDriver(e.getMessage());
			Log.error("WebDriver error while verifying WebElement with "+type+" "+value);
		}
		catch(Exception e){
			this.forceQuitDriver(e.getMessage());
			Log.error("Error while verifying WebElement with "+type+" "+value);
		}
		return false;
	}

	public boolean isAlertPresent(){
		try{
			driver.switchTo().alert();
			return true;
		}catch(Exception e){
			return false;
		}
	}

	public void acceptAlert(){
		try {
			Log.info("Expecting Alert on page");
			int counter=0;
			while(counter<100){
				if(isAlertPresent()){
					Log.info("Alert Found on Page");
					driver.switchTo().alert().accept();
					Log.info("Alert Accepted. Resuming execution");
					return;
				}
				counter++;
			}
			throw new NoAlertPresentException();
		}catch (NoAlertPresentException e) {
			Log.info("No Alert Present on Page");
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			Log.error("Error encountered while handling alert");
		}
	}

	public void clickOnElement(WebElement element){
		try{
			if(element==null)
				throw new NoSuchElementException("Element not located");
			element.click();
			Log.info("Click performed on WebElement "+element);
		}catch(NoSuchElementException e){
			this.forceQuitDriver(e.getMessage());
			Log.error("Error while performing click. Unable to click on NULL WebElement");
		}catch(ElementNotVisibleException e){
			this.forceQuitDriver(e.getMessage());
			Log.error("Error while performing click on WebElement "+element+". Element not visile");
		}catch(Exception e){
			this.forceQuitDriver(e.getMessage());
			Log.error("Error encountered while performing click");
		}	
	}

	public void enterKey(WebElement element,String key){
		try{
			if(element==null)
				throw new NoSuchElementException("Element not located");
			element.sendKeys(key);
			Log.info("Entered text <"+key+"> on WebElement "+element);
		}catch(NoSuchElementException e){
			this.forceQuitDriver(e.getMessage());
			Log.error("Error while performing click. Unable to click on NULL WebElement");
		}catch(ElementNotVisibleException e){
			this.forceQuitDriver(e.getMessage());
			Log.error("Error while typing text on WebElement "+element+". Element not visile");
		}catch(Exception e){
			this.forceQuitDriver(e.getMessage());
			Log.error("Error while typing text on WebElement "+element);
		}	
	}
	
	public void selectFromDropDown(WebElement element, String by, String value){
		try{
			if(element==null)
				throw new NoSuchElementException("No Such Element Found");
			Select select = new Select(element);
			if(by.equals("index")){
				select.selectByIndex(Integer.parseInt(value));
			}
			else if(by.equals("value")){
				select.selectByValue(value);
			}
			else if(by.equals("text")){
				select.selectByVisibleText(value);
			}
			Log.info("Selected "+value+" from drop down "+element+" with "+by);
		}catch(NoSuchElementException e){
			Log.error("Error while selecting from drop down. Unable to select from NULL drop down");
		}catch(UnsupportedOperationException e){
			Log.error("Multiple selection not allowed in drop down "+element);
		}catch(Exception e){
			Log.error("Error while selecting "+value+" by "+by+"from drop down "+element);
		}
	}

}
