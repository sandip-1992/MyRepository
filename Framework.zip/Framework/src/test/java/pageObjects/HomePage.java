package pageObjects;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;

import utilities.ObjectRepository;

public class HomePage extends BasePage{
	private static String xpath_addUserButton=ObjectRepository.getLocator("AddUserButton", "XPATH");
	private static String xpath_retrieveUserButton=ObjectRepository.getLocator("RetrieveUserButton", "XPATH");
	private WebElement addUserButton;
	private WebElement retrieveUserButton;
	public void getHomePage(){
		try{
			this.initiateDriver();
			this.getUrl();
			
		}catch(Exception e){
			e.printStackTrace();
			this.forceQuitDriver(e.getMessage());
		}
	}

	public void getAddUserPage(){
		try{
			addUserButton=this.getElement("xpath", xpath_addUserButton);
			this.clickOnElement(addUserButton);
		}catch(Exception e){
			e.printStackTrace();
			this.forceQuitDriver(e.getMessage());
		}
	}
	
	public void getRetrieveUserPage(){
		try{
			retrieveUserButton=this.getElement("xpath", xpath_retrieveUserButton);
			this.clickOnElement(retrieveUserButton);
		}catch(Exception e){
			e.printStackTrace();
			this.forceQuitDriver(e.getMessage());
		}
	}
	
	public void closeApplication(){
		try{
			this.quitDriver();
		}catch(Exception e){
			e.printStackTrace();
			this.forceQuitDriver(e.getMessage());
		}
	}
}
