package pageObjects;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;

import utilities.ObjectRepository;

public class RetrieveUserPage extends BasePage{
	private static String xpath_retrieveUserPageText=ObjectRepository.getLocator("RetrieveUserPageText", "XPATH");
	private WebElement retrieveUserPageText;
	public boolean verifyRetrieveUserPage(){
		try{
			retrieveUserPageText=this.getElement("xpath", xpath_retrieveUserPageText);
			if(retrieveUserPageText.getText().equalsIgnoreCase("RETRIEVE USER"))
				return true;
			else
				return false;
		}catch(Exception e){
			e.printStackTrace();
			this.forceQuitDriver(e.getMessage());
			return false;
		}
	}
}
