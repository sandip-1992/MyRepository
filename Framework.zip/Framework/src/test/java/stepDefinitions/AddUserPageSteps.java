package stepDefinitions;


import cucumber.api.java.Before;
import cucumber.api.java.en.Then;
import cucumber.api.Scenario;
import pageObjects.AddUserPage;
import pageObjects.BasePage;
import utilities.Assert;
import utilities.Defect;
import utilities.DefectFactory;
import utilities.ScreenshotController;

public class AddUserPageSteps {
	AddUserPage addUserPage=new AddUserPage();



	@Then("^Add User page should be displayed$")
	public void add_User_page_should_be_displayed() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		//throw new PendingException();
		ScreenshotController.takeScreenshot();
		Assert.assertResult("Unable to Get Add User Page", true,addUserPage.verifyAddUserPage());	
		ScreenshotController.takeScreenshot();
	
	}
}
