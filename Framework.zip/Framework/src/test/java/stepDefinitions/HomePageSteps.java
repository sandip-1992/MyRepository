package stepDefinitions;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.Scenario;
import pageObjects.BasePage;
import pageObjects.HomePage;
import utilities.ScreenshotController;

public class HomePageSteps {
	HomePage homePage=new HomePage();
	
	@Before
	public void setup(Scenario scenario){
		HomePage.setCurrentScenario(scenario.getName());
		HomePage.setScenarioId(scenario.getId());
		System.out.println(scenario.getName());
		System.out.println(scenario.getId());
	}
	
	
	@Given("^Data Store Application home page is displayed$")
	public void data_Store_Application_home_page_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		homePage.getHomePage();
		ScreenshotController.takeScreenshot();
	}

	@When("^User clicks on <Add User> button$")
	public void user_clicks_on_Add_User_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		homePage.getAddUserPage();
	}

	@When("^User clicks on <Retrieve User> button$")
	public void user_clicks_on_Retrieve_User_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		homePage.getRetrieveUserPage();
	}
	
	@Then("^User closes the application\\.$")
	public void user_closes_the_application() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		homePage.closeApplication();
	}
	

}
