package stepDefinitions;



import cucumber.api.java.en.Then;
import pageObjects.RetrieveUserPage;
import utilities.Assert;
import utilities.ScreenshotController;

public class RetrieveUserPageSteps {
	RetrieveUserPage retrieveUserPage=new RetrieveUserPage();
	@Then("^Retrieve User page should be displayed$")
	public void retrieve_User_page_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		ScreenshotController.takeScreenshot();
		Assert.assertResult("Unable to Get Retrieve User Page", true,retrieveUserPage.verifyRetrieveUserPage());
		ScreenshotController.takeScreenshot();
	}
}
