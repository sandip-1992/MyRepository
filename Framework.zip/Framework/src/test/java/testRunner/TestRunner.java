package testRunner;

import java.io.File;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import utilities.DefectFactory;
import utilities.Log;
import utilities.ObjectRepository;
import utilities.ScreenshotController;

@CucumberOptions(
	features={"src/test/resources/"},
	glue={"stepDefinitions"},
//	tags={"@Test"},
	format={"pretty","html:target/cucumber","json:target/cucumber.json"}
	
)
@RunWith(ExtendedCucumberRunner.class)
public class TestRunner {
    @BeforeSuite
    public static void setUp() {
        // TODO: Add your pre-processing
    	File logFile=new File("logfile.log");
    	logFile.delete();
    	Log.info("Preparing for new Execution");
    	ScreenshotController.cleanUp();
    	DefectFactory.clearDefectTrace();
    	ObjectRepository.loadRepository();
    }
    @AfterSuite
    public static void tearDown() {
        // TODO: Add your post-processing
    	DefectFactory.createDefectXML();
    	Log.info("Execution ended. All channels are stopped.");
    }
}

