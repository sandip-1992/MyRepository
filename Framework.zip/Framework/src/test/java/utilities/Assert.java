package utilities;



import pageObjects.BasePage;

public class Assert{
	public static void assertResult(String message, Object expected, Object actual){
		try{
			org.junit.Assert.assertEquals(message, expected,actual);
		}catch(AssertionError error){
			System.err.println("gjgfjn");
			System.out.println(new Exception().getStackTrace()[1].getClassName());
			System.out.println(BasePage.getCurrentScenario());
			System.out.println(BasePage.getScenarioId());
			System.out.println(error.getMessage());
			DefectFactory.addDefect(new Defect(new Exception().getStackTrace()[1].getClassName(), BasePage.getCurrentScenario(),BasePage.getScenarioId(),error.getMessage()));
			throw error;
		}
	}
}
