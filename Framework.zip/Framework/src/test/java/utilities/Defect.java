package utilities;

public class Defect {
	String summary;
	String description;
	
	public Defect(String className, String scenarioName,String scenarioId,String errorMessage) {
		super();
		this.summary=className.substring(className.indexOf('.')+1,className.length()-5)+" - "+
				errorMessage.substring(0,errorMessage.indexOf(':')-9);
		String line1="Feature : "+scenarioId.substring(0,1).toUpperCase()+scenarioId.replaceAll("-", " ").substring(1,scenarioId.indexOf(';'));
		String line2="Scenario : "+scenarioName;
		String line3="Error : "+errorMessage;
		this.description="{"+line1+"}        "+"{"+line2+"}        "+"{"+line3+"}";
	}
	
	public String getSummary() {
		return summary;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
}
