package utilities;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class DefectFactory {
	private static ArrayList<Defect> defectFactory=new ArrayList<Defect>();
	
	public static void addDefect(Defect defect){
		defectFactory.add(defect);
		System.out.println(defectFactory.size()+"Sdefdsgvdfgvdf");
	}
	
	public static void clearDefectTrace(){
		try{
			File file=new File("target\\DefectTrace.xml");
			file.delete();
			Log.info("Cleaning up existing defect trace");
		}catch(Exception e){
			e.printStackTrace();
			Log.error("Error while cleaning up existong defect trace");
		}
	}
	
	public static void createDefectXML(){
		try{
			Log.info("Analyzing Defects");
			System.out.println(defectFactory.size());
			if(defectFactory.size()==0)
				Log.info("No Defects Occured");
			else{
				String defectTarget="target\\DefectTrace.xml";
				System.out.println(defectTarget);
				DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
				Document doc = docBuilder.newDocument();
				Element rootElement = doc.createElement("defects");
				doc.appendChild(rootElement);
				for(Defect defect:defectFactory){
					Element defectNode=doc.createElement("defect");
					rootElement.appendChild(defectNode);
					Element summaryNode=doc.createElement("summary");
					summaryNode.appendChild(doc.createTextNode(defect.getSummary()));
					defectNode.appendChild(summaryNode);
					Element descNode=doc.createElement("description");
					descNode.appendChild(doc.createTextNode(defect.getDescription()));
					defectNode.appendChild(descNode);
				}
				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				Transformer transformer = transformerFactory.newTransformer();
				DOMSource source = new DOMSource(doc);
				StreamResult result = new StreamResult(new FileOutputStream(new File(defectTarget)));
				transformer.transform(source, result);
				Log.info(defectFactory.size()+" defects created");
			}
		}catch(Exception e){
			e.printStackTrace();
			Log.info("Error while registering defetcs to defect trace");
		}
	}
	
}
