package utilities;

import java.io.File;
import java.io.FileInputStream;
import java.util.Iterator;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class ObjectRepository {
	private static HSSFWorkbook repository;
	public static void loadRepository(){
		try{
			FileInputStream fis=new FileInputStream(new File("ObjectRepository.xls"));
			repository=new HSSFWorkbook(fis);
			fis.close();
			Log.info("Object Repository Loaded");
		}catch(Exception e){
			Log.error("Error occured while loading Object Repository");
			System.exit(0);
		}
	}
	public static String getLocator(String elementName, String locatorType){
		String locator=null;
		try{
			HSSFSheet page=repository.getSheet(new Exception().getStackTrace()[1].getClassName().substring(12));
			if(page==null)
				throw new Exception("No Such Page");
			Iterator rowIterator=page.rowIterator();
			while(rowIterator.hasNext()){
				HSSFRow row=(HSSFRow)rowIterator.next();
				if(row.getRowNum()==0)
					continue;
				if(row.getCell(0).getStringCellValue().equals(elementName)){
					if(row.getCell(1).getStringCellValue().equals(locatorType)){
						locator=row.getCell(2).getStringCellValue();
						break;
					}
				}
			}
			if(locator==null)
				throw new Exception("No Such Locator");
			else
				Log.info(locatorType+" loaded from object repository for "+elementName);
			return locator;
		}catch(Exception e){
			Log.info(locatorType+"not found from object repository for "+elementName);
		}
		return null;
	}
	
}
