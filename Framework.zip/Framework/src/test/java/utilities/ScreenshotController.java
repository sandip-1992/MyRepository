package utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.poi.util.Units;
import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;



import pageObjects.BasePage;

public class ScreenshotController {
	private static String screenshotTarget="target\\screenshots\\";
	private static String previousScenario="";
	private static String previousScenarioId="";
	private static int exampleCounter=1;
	private static int screenshotCounter=1;
	private static String screenshotName;
	public static void takeScreenshot(){
		try{
			if(BasePage.getCurrentScenario().equals(previousScenario)){
				if(BasePage.getScenarioId().equals(previousScenarioId)){
					screenshotName=previousScenario+"_"+exampleCounter;
					screenshotCounter++;
				}
				else{
					previousScenarioId=BasePage.getScenarioId();
					screenshotName=previousScenario+"_"+(++exampleCounter);
					screenshotCounter=1;
				}
			}
			else{
				previousScenario=BasePage.getCurrentScenario();
				previousScenarioId=BasePage.getScenarioId();
				exampleCounter=1;
				screenshotCounter=1;
				screenshotName=previousScenario+"_"+exampleCounter;
			}
			WebDriver screenDriver=BasePage.getDriver();
			File screenFile=((TakesScreenshot)screenDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenFile, new File(screenshotTarget+"RowScreenshot\\"+screenshotName+"\\"+"Screenshot "+Integer.toString(screenshotCounter)+".png"));
			addToDoc(screenshotTarget+"RowScreenshot\\"+screenshotName+"\\"+"Screenshot "+Integer.toString(screenshotCounter)+".png");
			Log.info("Screenshot captured using WebDriver");
		}catch(Exception e){
			e.printStackTrace();
			Log.error("Error while capturing screenshot using WebDriver");
		}
	}

	public static void addToDoc(String fileLocation){
		try{
			File file=new File(screenshotTarget+"ScreenshotDocs\\"+screenshotName+".docx");
			File folder=new File(screenshotTarget+"ScreenshotDocs");
			if(!folder.exists()){
				folder.mkdir();
			}
			if(!file.exists()){
				XWPFDocument doc=new XWPFDocument();
				FileOutputStream fos=new FileOutputStream(file);
				XWPFParagraph title=doc.createParagraph();
				XWPFRun run=title.createRun();
				run.setText(screenshotName);
				run.setBold(true);
				doc.write(fos);
				fos.close();
			}
			FileInputStream fis=new FileInputStream(screenshotTarget+"ScreenshotDocs\\"+screenshotName+".docx");
			XWPFDocument doc=new XWPFDocument(fis);
			XWPFParagraph title=doc.createParagraph();
			XWPFRun run=title.createRun();

			title.setAlignment(ParagraphAlignment.CENTER);
			String imgFile=fileLocation;
			FileInputStream is=new FileInputStream(imgFile);
			run.addBreak();
			run.addPicture(is,XWPFDocument.PICTURE_TYPE_PNG,imgFile,Units.toEMU(400),Units.toEMU(200));
			is.close();
			FileOutputStream fos=new FileOutputStream(screenshotTarget+"ScreenshotDocs\\"+screenshotName+".docx");
			doc.write(fos);
			fos.close();

		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public static void cleanUp(){
		try{
			Log.info("Cleaning up existing artefacts");
			File folder1=new File(screenshotTarget+"RowScreenshot");
			File folder2=new File(screenshotTarget+"ScreenshotDocs");
			File backup=new File("target\\Backups");
			if(!backup.exists()){
				backup.mkdir();
			}
			Date date=new Date();
			SimpleDateFormat sdf=new SimpleDateFormat("MM/dd/yyyy h:mm:ss a");
			String formattedDate=sdf.format(date);
			String backUpFolder=formattedDate.replaceAll("/", ".").replaceAll(":", ".");
			backup.mkdir();
			if(folder1.exists()){
				FileUtils.moveDirectory(folder1,new File("target\\Backups\\"+backUpFolder+"\\RowScreenshots"));
				folder1.mkdir();
			}
			else
				folder1.mkdir();
			if(folder2.exists()){
				FileUtils.moveDirectory(folder2,new File("target\\Backups\\"+backUpFolder+"\\ScreenshotDocs"));
				folder2.mkdir();
			}
			else
				folder2.mkdir();
			Log.info("Exixting artefacts cleaned and moved to BackUp folder");
		}catch(Exception e){
			e.printStackTrace();
			Log.error("Error while cleaning existing artefacts");
		}
	}
}
