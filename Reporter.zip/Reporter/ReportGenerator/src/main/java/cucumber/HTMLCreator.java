package cucumber;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.codehaus.plexus.util.DirectoryScanner;

import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;

public class HTMLCreator {
	  public static void generateReport(File reportFolder, File outputFolder) throws Exception {
		  	System.out.println(reportFolder.getAbsolutePath());
		  	System.out.println(outputFolder.getAbsolutePath());
	        File rd = new File(outputFolder + "/cucumber-html-reports");
	        List<String> jsonFileList = findJsonReports(reportFolder);

	        System.out.println("About to generate Cucumber Report into: " + rd.getAbsoluteFile());

	        Configuration configuration = new Configuration(rd, "cucumber-jvm");

	        ReportBuilder reportBuilder = new ReportBuilder(jsonFileList, configuration);
	        reportBuilder.generateReports();
	        System.out.println("Finished generating Cucumber Report into: " + rd.getAbsoluteFile());
	    }
	  
	  private static List<String> findJsonReports(File reportFolder) {
	        String[] jsonFiles = findJsonFiles(reportFolder);
	        List<String> reports = new ArrayList<>();

	        System.out.println("Found json reports: " + jsonFiles.length);
	        String reportPath = reportFolder.getAbsolutePath();
	        for (int i = 0; i < jsonFiles.length; i++) {
	            String reportJson = reportPath + "/" + jsonFiles[i];
	            System.out.println(reportJson);
	            reports.add(reportJson);
	        }
	        return reports;
	    }
	  private static String[] findJsonFiles(File targetDirectory) {
	        DirectoryScanner scanner = new DirectoryScanner();
	        scanner.setIncludes(new String[] {"**/*.json"});
	        scanner.setBasedir(targetDirectory);
	        scanner.scan();
	        return scanner.getIncludedFiles();
	    }
}
