package cucumber;

import java.io.File;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			HTMLCreator.generateReport(new File("D:\\source"), new File("D:\\target"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
