package cucumber;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

import org.jfree.chart.ChartPanel;


public class Window {

	private JFrame frame;
	private JFrame frame1;
	private String filePath;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Window window = new Window();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Window() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Cucumber Report Generator");
		frame.setBounds(100, 100, 472, 236);
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.setResizable(false);
		frame.getContentPane().setLayout(null);

		JLabel lblRegressionMonitor_1 = new JLabel("Cucumber Report Generator");
		lblRegressionMonitor_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblRegressionMonitor_1.setForeground(new Color(0, 0, 255));
		lblRegressionMonitor_1.setFont(new Font("Sitka Small", Font.BOLD, 16));
		lblRegressionMonitor_1.setBounds(112, 30, 251, 21);
		frame.getContentPane().add(lblRegressionMonitor_1);

		final JFileChooser chooser = new JFileChooser();
		chooser.setDialogTitle("Select Target Directory");
		chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		chooser.setAcceptAllFileFilterUsed(false);

		JButton btnSelectRepository = new JButton("Select JSON File Location");
		btnSelectRepository.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int returnVal = chooser.showOpenDialog((Component)e.getSource());
				if (returnVal == JFileChooser.APPROVE_OPTION) {
					File file = chooser.getSelectedFile();
					try {
						frame.setVisible(false);
						filePath=file.getAbsolutePath();
						frame.setVisible(false);
						int[][] result=new ResultProcessor().getResult(filePath+"\\cucumber.json");
						showDashBoard(result);

					} catch (Exception ex) {
						System.out.println("problem accessing file"+file.getAbsolutePath());
					}
				} 

			}
		});
		btnSelectRepository.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnSelectRepository.setForeground(Color.BLUE);
		btnSelectRepository.setBounds(130, 69, 201, 23);
		frame.getContentPane().add(btnSelectRepository);

		JButton btnClose_1 = new JButton("Close");
		btnClose_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnClose_1.setForeground(Color.BLUE);
		btnClose_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnClose_1.setBounds(130, 118, 201, 23);
		frame.getContentPane().add(btnClose_1);

		JLabel lblNewLabel_1 = new JLabel("By : Sandip");
		lblNewLabel_1.setForeground(new Color(128, 0, 0));
		lblNewLabel_1.setFont(new Font("Maiandra GD", Font.ITALIC, 18));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(233, 186, 357, 21);
		frame.getContentPane().add(lblNewLabel_1);
	}

	public void showDashBoard(int[][] result){
		frame1 = new JFrame("Cucumber Result DashBoard");
		frame1.getContentPane().setBackground(new Color(230, 230, 250));
		frame1.setBounds(40, 40, 1228, 659);
		frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame1.getContentPane().setLayout(null);
		frame1.setResizable(false);

		JPanel panelFeature = new JPanel();
		panelFeature.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panelFeature.setBounds(40, 91, 321, 115);
		frame1.getContentPane().add(panelFeature);
		panelFeature.setLayout(null);

		JPanel panelFeatureHeader = new JPanel();
		panelFeatureHeader.setBackground(new Color(255, 255, 255));
		panelFeatureHeader.setBounds(0, 0, 321, 39);
		panelFeatureHeader.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panelFeature.add(panelFeatureHeader);
		panelFeatureHeader.setLayout(null);

		JLabel lblFeature = new JLabel("Features");
		lblFeature.setForeground(new Color(165, 42, 42));
		lblFeature.setBounds(108, 11, 99, 22);
		panelFeatureHeader.add(lblFeature);
		lblFeature.setFont(new Font("Sylfaen", Font.BOLD, 24));
		lblFeature.setHorizontalAlignment(SwingConstants.CENTER);

		JPanel panelFeatureTotalHeader = new JPanel();
		panelFeatureTotalHeader.setBackground(new Color(204, 204, 0));
		panelFeatureTotalHeader.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panelFeatureTotalHeader.setBounds(0, 37, 109, 39);
		panelFeature.add(panelFeatureTotalHeader);
		panelFeatureTotalHeader.setLayout(null);

		JLabel lblTotal = new JLabel("Total");
		lblTotal.setHorizontalAlignment(SwingConstants.CENTER);
		lblTotal.setFont(new Font("Sylfaen", Font.BOLD, 18));
		lblTotal.setBounds(18, 11, 69, 17);
		panelFeatureTotalHeader.add(lblTotal);

		JPanel panelGeaturePassedHeader = new JPanel();
		panelGeaturePassedHeader.setBackground(new Color(0, 255, 0));
		panelGeaturePassedHeader.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panelGeaturePassedHeader.setBounds(105, 37, 109, 39);
		panelFeature.add(panelGeaturePassedHeader);
		panelGeaturePassedHeader.setLayout(null);

		JLabel lblPassed = new JLabel("Passed");
		lblPassed.setHorizontalAlignment(SwingConstants.CENTER);
		lblPassed.setFont(new Font("Sylfaen", Font.BOLD, 18));
		lblPassed.setBounds(19, 11, 69, 17);
		panelGeaturePassedHeader.add(lblPassed);

		JPanel panelFeatureFailedHeader = new JPanel();
		panelFeatureFailedHeader.setBackground(new Color(255, 0, 0));
		panelFeatureFailedHeader.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panelFeatureFailedHeader.setBounds(211, 37, 109, 39);
		panelFeature.add(panelFeatureFailedHeader);
		panelFeatureFailedHeader.setLayout(null);

		JLabel lblFailed = new JLabel("Failed");
		lblFailed.setHorizontalAlignment(SwingConstants.CENTER);
		lblFailed.setFont(new Font("Sylfaen", Font.BOLD, 18));
		lblFailed.setBounds(18, 11, 69, 17);
		panelFeatureFailedHeader.add(lblFailed);

		JPanel panelFeatureTotalValue = new JPanel();
		panelFeatureTotalValue.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panelFeatureTotalValue.setBounds(0, 69, 109, 46);
		panelFeature.add(panelFeatureTotalValue);
		panelFeatureTotalValue.setLayout(null);

		JLabel featureTotal = new JLabel("\r\n");
		featureTotal.setHorizontalAlignment(SwingConstants.CENTER);
		featureTotal.setFont(new Font("Sylfaen", Font.BOLD, 18));
		featureTotal.setBounds(19, 18, 69, 17);
		panelFeatureTotalValue.add(featureTotal);

		JPanel panelFeaturePassedValue = new JPanel();
		panelFeaturePassedValue.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panelFeaturePassedValue.setBounds(105, 69, 109, 46);
		panelFeature.add(panelFeaturePassedValue);
		panelFeaturePassedValue.setLayout(null);

		JLabel featurePassed = new JLabel("");
		featurePassed.setHorizontalAlignment(SwingConstants.CENTER);
		featurePassed.setFont(new Font("Sylfaen", Font.BOLD, 18));
		featurePassed.setBounds(19, 18, 69, 17);
		panelFeaturePassedValue.add(featurePassed);

		JPanel panelFeatureFailedValue = new JPanel();
		panelFeatureFailedValue.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panelFeatureFailedValue.setBounds(211, 69, 109, 46);
		panelFeature.add(panelFeatureFailedValue);
		panelFeatureFailedValue.setLayout(null);

		JLabel featureFailed = new JLabel("");
		featureFailed.setHorizontalAlignment(SwingConstants.CENTER);
		featureFailed.setFont(new Font("Sylfaen", Font.BOLD, 18));
		featureFailed.setBounds(19, 18, 69, 17);
		panelFeatureFailedValue.add(featureFailed);

		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.setBounds(393, 91, 321, 115);
		frame1.getContentPane().add(panel);

		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(0, 0, 321, 39);
		panel.add(panel_1);

		JLabel lblScenario = new JLabel("Scenarios");
		lblScenario.setHorizontalAlignment(SwingConstants.CENTER);
		lblScenario.setForeground(new Color(165, 42, 42));
		lblScenario.setFont(new Font("Sylfaen", Font.BOLD, 24));
		lblScenario.setBounds(109, 11, 108, 22);
		panel_1.add(lblScenario);

		JPanel panel_2 = new JPanel();
		panel_2.setLayout(null);
		panel_2.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel_2.setBackground(new Color(204, 204, 0));
		panel_2.setBounds(0, 37, 109, 39);
		panel.add(panel_2);

		JLabel label_1 = new JLabel("Total");
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setFont(new Font("Sylfaen", Font.BOLD, 18));
		label_1.setBounds(18, 11, 69, 17);
		panel_2.add(label_1);

		JPanel panel_3 = new JPanel();
		panel_3.setLayout(null);
		panel_3.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel_3.setBackground(Color.GREEN);
		panel_3.setBounds(105, 37, 109, 39);
		panel.add(panel_3);

		JLabel label_2 = new JLabel("Passed");
		label_2.setHorizontalAlignment(SwingConstants.CENTER);
		label_2.setFont(new Font("Sylfaen", Font.BOLD, 18));
		label_2.setBounds(19, 11, 69, 17);
		panel_3.add(label_2);

		JPanel panel_4 = new JPanel();
		panel_4.setLayout(null);
		panel_4.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel_4.setBackground(Color.RED);
		panel_4.setBounds(211, 37, 109, 39);
		panel.add(panel_4);

		JLabel label_3 = new JLabel("Failed");
		label_3.setHorizontalAlignment(SwingConstants.CENTER);
		label_3.setFont(new Font("Sylfaen", Font.BOLD, 18));
		label_3.setBounds(18, 11, 69, 17);
		panel_4.add(label_3);

		JPanel panel_5 = new JPanel();
		panel_5.setLayout(null);
		panel_5.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel_5.setBounds(0, 69, 109, 46);
		panel.add(panel_5);

		JLabel scenarioTotal = new JLabel("\r\n");
		scenarioTotal.setHorizontalAlignment(SwingConstants.CENTER);
		scenarioTotal.setFont(new Font("Sylfaen", Font.BOLD, 18));
		scenarioTotal.setBounds(19, 18, 69, 17);
		panel_5.add(scenarioTotal);

		JPanel panel_6 = new JPanel();
		panel_6.setLayout(null);
		panel_6.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel_6.setBounds(105, 69, 109, 46);
		panel.add(panel_6);

		JLabel scenarioPassed = new JLabel("");
		scenarioPassed.setHorizontalAlignment(SwingConstants.CENTER);
		scenarioPassed.setFont(new Font("Sylfaen", Font.BOLD, 18));
		scenarioPassed.setBounds(19, 18, 69, 17);
		panel_6.add(scenarioPassed);

		JPanel panel_7 = new JPanel();
		panel_7.setLayout(null);
		panel_7.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel_7.setBounds(211, 69, 109, 46);
		panel.add(panel_7);

		JLabel scenarioFailed = new JLabel("");
		scenarioFailed.setHorizontalAlignment(SwingConstants.CENTER);
		scenarioFailed.setFont(new Font("Sylfaen", Font.BOLD, 18));
		scenarioFailed.setBounds(19, 18, 69, 17);
		panel_7.add(scenarioFailed);

		JPanel panel_8 = new JPanel();
		panel_8.setLayout(null);
		panel_8.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel_8.setBounds(747, 91, 425, 115);
		frame1.getContentPane().add(panel_8);

		JPanel panel_9 = new JPanel();
		panel_9.setLayout(null);
		panel_9.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel_9.setBackground(Color.WHITE);
		panel_9.setBounds(0, 0, 425, 39);
		panel_8.add(panel_9);

		JLabel lblSteps = new JLabel("Steps");
		lblSteps.setHorizontalAlignment(SwingConstants.CENTER);
		lblSteps.setForeground(new Color(165, 42, 42));
		lblSteps.setFont(new Font("Sylfaen", Font.BOLD, 24));
		lblSteps.setBounds(161, 11, 99, 22);
		panel_9.add(lblSteps);

		JPanel panel_10 = new JPanel();
		panel_10.setLayout(null);
		panel_10.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel_10.setBackground(new Color(204, 204, 0));
		panel_10.setBounds(0, 37, 109, 39);
		panel_8.add(panel_10);

		JLabel label_4 = new JLabel("Total");
		label_4.setHorizontalAlignment(SwingConstants.CENTER);
		label_4.setFont(new Font("Sylfaen", Font.BOLD, 18));
		label_4.setBounds(18, 11, 69, 17);
		panel_10.add(label_4);

		JPanel panel_11 = new JPanel();
		panel_11.setLayout(null);
		panel_11.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel_11.setBackground(Color.GREEN);
		panel_11.setBounds(105, 37, 109, 39);
		panel_8.add(panel_11);

		JLabel label_5 = new JLabel("Passed");
		label_5.setHorizontalAlignment(SwingConstants.CENTER);
		label_5.setFont(new Font("Sylfaen", Font.BOLD, 18));
		label_5.setBounds(19, 11, 69, 17);
		panel_11.add(label_5);

		JPanel panel_12 = new JPanel();
		panel_12.setLayout(null);
		panel_12.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel_12.setBackground(Color.RED);
		panel_12.setBounds(211, 37, 109, 39);
		panel_8.add(panel_12);

		JLabel label_6 = new JLabel("Failed");
		label_6.setHorizontalAlignment(SwingConstants.CENTER);
		label_6.setFont(new Font("Sylfaen", Font.BOLD, 18));
		label_6.setBounds(18, 11, 69, 17);
		panel_12.add(label_6);

		JPanel panel_13 = new JPanel();
		panel_13.setLayout(null);
		panel_13.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel_13.setBounds(0, 69, 109, 46);
		panel_8.add(panel_13);

		JLabel stepTotal = new JLabel("\r\n");
		stepTotal.setHorizontalAlignment(SwingConstants.CENTER);
		stepTotal.setFont(new Font("Sylfaen", Font.BOLD, 18));
		stepTotal.setBounds(19, 18, 69, 17);
		panel_13.add(stepTotal);

		JPanel panel_14 = new JPanel();
		panel_14.setLayout(null);
		panel_14.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel_14.setBounds(105, 69, 109, 46);
		panel_8.add(panel_14);

		JLabel stepPassed = new JLabel("");
		stepPassed.setHorizontalAlignment(SwingConstants.CENTER);
		stepPassed.setFont(new Font("Sylfaen", Font.BOLD, 18));
		stepPassed.setBounds(19, 18, 69, 17);
		panel_14.add(stepPassed);

		JPanel panel_15 = new JPanel();
		panel_15.setLayout(null);
		panel_15.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel_15.setBounds(211, 69, 109, 46);
		panel_8.add(panel_15);

		JLabel stepFailed = new JLabel("");
		stepFailed.setHorizontalAlignment(SwingConstants.CENTER);
		stepFailed.setFont(new Font("Sylfaen", Font.BOLD, 18));
		stepFailed.setBounds(19, 18, 69, 17);
		panel_15.add(stepFailed);

		JPanel panel_16 = new JPanel();
		panel_16.setLayout(null);
		panel_16.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel_16.setBackground(new Color(102, 102, 255));
		panel_16.setBounds(316, 37, 109, 39);
		panel_8.add(panel_16);

		JLabel lblSkipped = new JLabel("Skipped");
		lblSkipped.setHorizontalAlignment(SwingConstants.CENTER);
		lblSkipped.setFont(new Font("Sylfaen", Font.BOLD, 18));
		lblSkipped.setBounds(18, 11, 69, 17);
		panel_16.add(lblSkipped);

		JPanel panel_17 = new JPanel();
		panel_17.setLayout(null);
		panel_17.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel_17.setBounds(316, 69, 109, 46);
		panel_8.add(panel_17);

		JLabel stepSkipped = new JLabel("");
		stepSkipped.setHorizontalAlignment(SwingConstants.CENTER);
		stepSkipped.setFont(new Font("Sylfaen", Font.BOLD, 18));
		stepSkipped.setBounds(19, 18, 69, 17);
		panel_17.add(stepSkipped);

		JPanel panelFeaturePlot = new JPanel();
		panelFeaturePlot.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panelFeaturePlot.setBounds(40, 219, 321, 295);
		frame1.getContentPane().add(panelFeaturePlot);

		JPanel panelScenarioPlot = new JPanel();
		panelScenarioPlot.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panelScenarioPlot.setBounds(393, 217, 321, 295);
		frame1.getContentPane().add(panelScenarioPlot);

		JPanel panel_18 = new JPanel();
		panel_18.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel_18.setBounds(747, 217, 425, 295);
		frame1.getContentPane().add(panel_18);
		panel_18.setLayout(null);

		JPanel panelStepPlot = new JPanel();
		panelStepPlot.setBounds(51, 2, 321, 291);
		panel_18.add(panelStepPlot);


		final JFileChooser chooser = new JFileChooser();
		chooser.setDialogTitle("Select Directory");
		chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		chooser.setAcceptAllFileFilterUsed(false);
		JButton btnDataButton = new JButton("Generate HTML");
		btnDataButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int returnVal = chooser.showOpenDialog((Component)e.getSource());
				if (returnVal == JFileChooser.APPROVE_OPTION) {
					File file = chooser.getSelectedFile();
					try {
						HTMLCreator.generateReport(new File(filePath), file);
						JOptionPane.showMessageDialog(null, "HTML Report generated at "+file.getAbsolutePath());
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
						JOptionPane.showMessageDialog(null, "Error while generating HTML Report");
					}
				}
			}
		});
		btnDataButton.setBackground(new Color(227, 230, 250));
		btnDataButton.setFont(new Font("Sylfaen", Font.BOLD, 16));
		btnDataButton.setBounds(328, 550, 185, 35);
		frame1.getContentPane().add(btnDataButton);

		JButton btnNewButton = new JButton("Close");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame1.setVisible(false);
			}
		});
		btnNewButton.setBackground(new Color(227, 230, 250));
		btnNewButton.setFont(new Font("Sylfaen", Font.BOLD, 16));
		btnNewButton.setBounds(728, 550, 185, 35);
		frame1.getContentPane().add(btnNewButton);



		featureTotal.setText(Integer.toString(result[0][0]));
		featurePassed.setText(Integer.toString(result[0][1]));
		featureFailed.setText(Integer.toString(result[0][2]));

		scenarioTotal.setText(Integer.toString(result[1][0]));
		scenarioPassed.setText(Integer.toString(result[1][1]));
		scenarioFailed.setText(Integer.toString(result[1][2]));

		stepTotal.setText(Integer.toString(result[2][0]));
		stepPassed.setText(Integer.toString(result[2][1]));
		stepFailed.setText(Integer.toString(result[2][2]));
		stepSkipped.setText(Integer.toString(result[2][3]));

		ChartPanel featureChartPanel=new ChartPanel(PieChartCreator.createChart(new int[]{result[0][0], result[0][1],result[0][2]},"Feature"));
		ChartPanel scenarioChartPanel=new ChartPanel(PieChartCreator.createChart(new int[]{result[1][0], result[1][1],result[1][2]},"Scenario"));
		ChartPanel stepChartPanel=new ChartPanel(PieChartCreator.createChart(new int[]{result[2][0], result[2][1],result[2][2],result[2][3]},"Step"));

		panelFeaturePlot.setLayout(new java.awt.BorderLayout());
		panelScenarioPlot.setLayout(new java.awt.BorderLayout());
		panelStepPlot.setLayout(new java.awt.BorderLayout());

		featureChartPanel.setDisplayToolTips(true);
		scenarioChartPanel.setDisplayToolTips(true);
		stepChartPanel.setDisplayToolTips(true);

		panelFeaturePlot.add(featureChartPanel,BorderLayout.CENTER);
		panelScenarioPlot.add(scenarioChartPanel,BorderLayout.CENTER);
		panelStepPlot.add(stepChartPanel,BorderLayout.CENTER);

		JLabel lblDashboard = new JLabel("Cucumber Result DashBoard");
		lblDashboard.setForeground(new Color(51, 0, 0));
		lblDashboard.setHorizontalAlignment(SwingConstants.CENTER);
		lblDashboard.setFont(new Font("Sylfaen", Font.BOLD, 28));
		lblDashboard.setBounds(40, 27, 1132, 35);
		frame1.getContentPane().add(lblDashboard);

		frame1.setVisible(true);

	}

}
